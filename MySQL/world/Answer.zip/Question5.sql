SELECT name, surface_area, population from countries
WHERE surface_area<501 AND population>100000